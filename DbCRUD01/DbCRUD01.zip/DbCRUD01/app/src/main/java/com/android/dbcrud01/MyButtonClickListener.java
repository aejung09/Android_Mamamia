package com.android.dbcrud01;

public interface MyButtonClickListener {
    void onClick(int pos);
}
